package com.launcher.cachi.bean;

import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class AppItem {

	public RelativeLayout layout;
	public ImageView imageView1,imageView2,imageView3;
	public TextView textView;
	public String packageName = null;
}
