package com.launcher.cachi.utils;

/**
 * 数据回调接口
 */
public interface IOAuthCallBack {
	public void getIOAuthCallBack(String result,int state);
}
