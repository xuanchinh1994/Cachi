package com.launcher.cachi.activitys.speedtest;

public class NetworkSpeedInfo {
    public static long Speed = 0;
    public static long FinishBytes = 0;
    public static long totalBytes = 1024;
    public static Boolean FILECANREAD = true;
    public int networkType = 0;
    public int loadFileNum = 0;
    public static int progress;
}
